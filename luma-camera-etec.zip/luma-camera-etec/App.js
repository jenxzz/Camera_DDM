import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  PermissionsAndroid,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { useState, useRef } from 'react';
import {
  SafeAreaProvider,
  SafeAreaView,
} from 'react-native-safe-area-context';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as MediaLibrary from 'expo-media-library';

export default function App() {
  return (
    <SafeAreaProvider>
      <TelaCamera />
    </SafeAreaProvider>
  );
}

function TelaCamera() {
  const [permissaoCamera, requestCameraPermission] = useCameraPermissions();
  const [permissaoGaleria, requestMediaPermission] = MediaLibrary.usePermissions({ writeOnly: true });
  const [salvando, setSalvando] = useState(false);
  const camera = useRef(null);

  if (!permissaoCamera || !permissaoGaleria) {
    return (
      <SafeAreaView style={styles.container}>
        <ActivityIndicator size="large" color="#B8FF65" />
        <Text style={styles.texto}>Carregando câmera...</Text>
      </SafeAreaView>
    );
  }

  const temPermissao = permissaoCamera.granted && permissaoGaleria.granted;

  async function pedirPermissoes() {
    const cam = await requestCameraPermission();

    if (cam.granted) {
      await requestMediaPermission();
    }
  }

  async function tirarFoto() {
    if (!camera.current || salvando) {
      return;
    }

    setSalvando(true);

    try {
      const foto = await camera.current.takePictureAsync({
        quality: 0.8,
      });

      await MediaLibrary.createAssetAsync(foto.uri);
      Alert.alert('Sucesso', 'Foto salva na galeria!');
    } catch (error) {
      console.log(error);
      Alert.alert('Erro', 'Erro ao salvar a foto na galeria.');
    } finally {
      setSalvando(false);
    }
  }

  if (!temPermissao) {
    return (
      <SafeAreaView style={styles.container}>
        <Text style={styles.titulo}>CÂMERA</Text>
        <Text style={styles.texto}>
          É necessária a permissão da câmera e da galeria.
        </Text>
        <TouchableOpacity style={styles.botaoPermissao} onPress={pedirPermissoes}>
          <Text style={styles.textoBotao}>Conceder permissões</Text>
        </TouchableOpacity>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.titulo}>CÂMERA</Text>
      <Text style={styles.subtitulo}>Registre seus momentos</Text>

      <View style={styles.areaCamera}>
        <CameraView ref={camera} style={styles.camera} />
      </View>

      <Text style={styles.texto}>Pronto para tirar uma foto?</Text>

      <TouchableOpacity
        style={styles.botaoFoto}
        onPress={tirarFoto}
        disabled={salvando}
      >
        {salvando ? (
          <ActivityIndicator color="#10110F" />
        ) : (
          <Text style={styles.textoBotao}>Tirar foto</Text>
        )}
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#10110F',
    padding: 20,
    justifyContent: 'center',
  },
  titulo: {
    color: '#B8FF65',
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 8,
  },
  subtitulo: {
    color: '#FFFFFF',
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 20,
  },
  texto: {
    color: '#FFFFFF',
    fontSize: 16,
    textAlign: 'center',
    marginVertical: 18,
  },
  areaCamera: {
    flex: 1,
    maxHeight: 480,
    overflow: 'hidden',
    borderRadius: 16,
    backgroundColor: '#252620',
  },
  camera: {
    flex: 1,
  },
  botaoPermissao: {
    backgroundColor: '#B8FF65',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
  },
  botaoFoto: {
    backgroundColor: '#B8FF65',
    padding: 18,
    borderRadius: 30,
    alignItems: 'center',
    marginTop: 12,
  },
  textoBotao: {
    color: '#10110F',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
