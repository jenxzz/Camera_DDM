# Camera_3_INFO_TB

Projeto baseado no repositório disponibilizado pelo professor para a atividade de finalização do aplicativo de câmera.

## Bibliotecas utilizadas
- `expo-camera`: exibe a câmera e permite tirar fotos.
- `expo-media-library`: salva a foto na galeria.
- `react-native-safe-area-context`: mantém o conteúdo dentro da área segura da tela.

## Como executar
1. Instale o Node.js e o Expo.
2. No terminal, dentro desta pasta, execute `npm install`.
3. Execute `npx expo start`.
4. Abra o projeto no celular com Expo Go para testar a câmera.
